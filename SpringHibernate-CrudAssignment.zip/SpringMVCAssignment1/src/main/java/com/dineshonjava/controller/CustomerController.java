package com.dineshonjava.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.dineshonjava.bean.CustomerBean;
import com.dineshonjava.model.Customer;
import com.dineshonjava.service.CustomerService;

 
@Controller
public class CustomerController 
{
	
	@Autowired
	private CustomerService customerService;
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public ModelAndView saveCustomer(@ModelAttribute("command") CustomerBean customerBean, 
			BindingResult result) {
		Customer customer = prepareModel(customerBean);
		customerService.addCustomer(customer);
		return new ModelAndView("redirect:/add.html");
	}

	@RequestMapping(value="/customers", method = RequestMethod.GET)
	public ModelAndView listCustomers() {
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("customers",  prepareListofBean(customerService.listCustomers()));
		return new ModelAndView("CustomerList", model);
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public ModelAndView addCustomer(@ModelAttribute("command")  CustomerBean customerBean,
			BindingResult result) 
	{
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("customers",  prepareListofBean(customerService.listCustomers()));
		return new ModelAndView("addCustomer", model);
	}
	
	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public ModelAndView welcome() {
		return new ModelAndView("index");
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public ModelAndView editCustomer(@ModelAttribute("command")  CustomerBean customerBean,
			BindingResult result) {
		customerService.deleteCustomer(prepareModel(customerBean));
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("customer", null);
		model.put("customers",  prepareListofBean(customerService.listCustomers()));
		return new ModelAndView("addCustomer", model);
	}
	
	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView deleteCustomer(@ModelAttribute("command")  CustomerBean customerBean,
			BindingResult result)
	{
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("customer", prepareCustomerBean(customerService.getCustomer(customerBean.getId())));
		model.put("customers",  prepareListofBean(customerService.listCustomers()));
		return new ModelAndView("addCustomer", model);
	}
	
	
	
	
	private Customer prepareModel(CustomerBean customerBean){
		Customer customer = new Customer();
		customer.setCusName(customerBean.getName());
		customer.setCusAddress(customerBean.getAddress());
		customer.setCusphoneno(customerBean.getPhoneno());
		customer.setCusemail(customerBean.getEmail());
		customer.setCuscompname(customerBean.getCompname());
		customer.setCusAge(customerBean.getAge());
		customer.setCusopenbalance(customerBean.getOpenbalance());
		customer.setCusId(customerBean.getId());
		customerBean.setId(null);
		return customer;
	}
	
	private List<CustomerBean> prepareListofBean(List<Customer> customers){
		List<CustomerBean> beans = null;
		if(customers != null && !customers.isEmpty()){
			beans = new ArrayList<CustomerBean>();
			CustomerBean bean = null;
			for(Customer customer : customers){
				bean = new CustomerBean();
				bean.setName(customer.getCusName());
				bean.setId(customer.getCusId());
				bean.setAddress(customer.getCusAddress());
				bean.setPhoneno(customer.getCusphoneno());
				bean.setEmail(customer.getCusemail());
				bean.setCompname(customer.getCuscompname());
				bean.setAge(customer.getCusAge());
				bean.setOpenbalance(customer.getCusopenbalance());
				beans.add(bean);
			}
		}
		return beans;
	}
	
	private CustomerBean prepareCustomerBean(Customer customer){
		CustomerBean bean = new CustomerBean();
		bean.setName(customer.getCusName());
		bean.setAddress(customer.getCusAddress());
		bean.setPhoneno(customer.getCusphoneno());
		bean.setEmail(customer.getCusemail());
		bean.setCompname(customer.getCuscompname());
		bean.setAge(customer.getCusAge());
		bean.setOpenbalance(customer.getCusopenbalance());
		bean.setId(customer.getCusId());
		return bean;
	}
}






