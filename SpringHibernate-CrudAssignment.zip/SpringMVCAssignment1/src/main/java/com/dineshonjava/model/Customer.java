package com.dineshonjava.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

 
@SuppressWarnings({ "serial", "unused" })
@Entity
@Table(name="Customer")
public class Customer implements Serializable{


	@Id
	 
	@Column(name = "cusid")
	private Integer cusId;
	
	@Column(name="cusname")
	private String cusName;
	
	@Column(name="cusaddress")
	private String cusAddress;
	
	@Column(name="cusphoneno")
	private Long cusphoneno;
	
	@Column(name="cusemail")
	private String cusemail;
	
	@Column(name="cuscompname")
	private String cuscompname;
	
	@Column(name="cusAge")
	private Integer cusAge;
	
	@Column(name="cusopenbalance")
	private Long cusopenbalance;

	public Integer getCusId() {
		return cusId;
	}

	public void setCusId(Integer cusId) {
		this.cusId = cusId;
	}

	public String getCusName() {
		return cusName;
	}

	public void setCusName(String cusName) {
		this.cusName = cusName;
	}

	public String getCusAddress() {
		return cusAddress;
	}

	public void setCusAddress(String cusAddress) {
		this.cusAddress = cusAddress;
	}

	public Long getCusphoneno() {
		return cusphoneno;
	}

	public void setCusphoneno(Long cusphoneno) {
		this.cusphoneno = cusphoneno;
	}

	public String getCusemail() {
		return cusemail;
	}

	public void setCusemail(String cusemail) {
		this.cusemail = cusemail;
	}

	public String getCuscompname() {
		return cuscompname;
	}

	public void setCuscompname(String cuscompname) {
		this.cuscompname = cuscompname;
	}

	public Integer getCusAge() {
		return cusAge;
	}

	public void setCusAge(Integer cusAge) {
		this.cusAge = cusAge;
	}

	public Long getCusopenbalance() {
		return cusopenbalance;
	}

	public void setCusopenbalance(Long cusopenbalance) {
		this.cusopenbalance = cusopenbalance;
	}

	
	
	
}
