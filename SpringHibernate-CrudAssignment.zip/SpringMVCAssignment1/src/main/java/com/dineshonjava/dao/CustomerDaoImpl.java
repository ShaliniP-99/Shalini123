package com.dineshonjava.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.dineshonjava.model.Customer;

 
@Repository("customerDao")
public class CustomerDaoImpl implements CustomerDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	public void addCustomer(Customer customer) {
		sessionFactory.getCurrentSession().saveOrUpdate(customer);
	}


	@SuppressWarnings("unchecked")
	public List<Customer> listCustomers() 
	{
		return (List<Customer>) sessionFactory.openSession().createCriteria(Customer.class).list();
	}

	public Customer getCustomer(int cusid) {
		return (Customer) sessionFactory.getCurrentSession().get(Customer.class, cusid);
	}

	public void deleteCustomer(Customer customer) {
		sessionFactory.getCurrentSession().createQuery("DELETE FROM Customer WHERE cusid = "+customer.getCusId()).executeUpdate();
	}

}
