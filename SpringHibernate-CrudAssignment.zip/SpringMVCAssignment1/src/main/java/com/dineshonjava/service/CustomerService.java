package com.dineshonjava.service;

import java.util.List;

import com.dineshonjava.model.Customer;

 
public interface CustomerService {
	
	public void addCustomer(Customer customer);

	public List<Customer> listCustomers();
	
	public Customer getCustomer(int cusid);
	
	public void deleteCustomer(Customer customer);
}
