import java.util.*;

import org.hibernate.*;
import org.hibernate.cfg.*;

public class part {
	
	public static void main(String args[]) {
		Configuration cfg=new Configuration();
		SessionFactory sf=cfg.configure().buildSessionFactory();
		Session ss=sf.openSession();
		mypojo pojo=new mypojo();
		
		String empno, name, phoneno, address;
		Scanner sc = new Scanner(System.in);
		
		while(true) {
			System.out.println("Select 1 for Inserting");
			System.out.println("Select 2 for Deleting");
			System.out.println("Select 3 for Updating");
			System.out.println("Select 4 for Display");
			System.out.println("Select 5 for Exit");
			int x = sc.nextInt();
			switch(x) {
			case 1:
				Transaction tx=ss.beginTransaction();
				Query q=ss.createQuery("from mypojo");  //query select from mypojo class(table)
				
				System.out.println("Inserting values");
				System.out.println("Enter Employee Number");
				empno = sc.next();
				pojo.setEmpno(empno);
				System.out.println("Enter Employee's name");
				name = sc.next();
				pojo.setName(name);
				System.out.println("Enter Employee's Mobile Number");
				phoneno = sc.next();
				pojo.setPhoneno(phoneno);
				System.out.println("Enter Employee's address");
				address = sc.next();
				pojo.setAddress(address);
				ss.save(pojo);
			
				
				q.setFirstResult(0);  
				q.setMaxResults(10);  
				List list=q.list();//will return the records from 0 to 10th number
				System.out.println(list);
				tx.commit(); 
				break;
				
			case 2:
				Transaction tx1=ss.beginTransaction();
				System.out.println("Deleting data");
				System.out.println("Enter Employee's id for deleteing ");
				empno = sc.next();
				Query q3=ss.createQuery("delete from mypojo where empno=:i");
				q3.setParameter("i", empno);
				q3.executeUpdate(); 
				System.out.println(empno + " row Deleted");
				tx1.commit();			
				break;
				
			case 3:
				Transaction tx2=ss.beginTransaction();
				System.out.println("Updating data ");
				System.out.println("Enter the Employee number for updating");
				empno = sc.next();
				System.out.println("Enter Employee's Name");
				name = sc.next();
				System.out.println("Enter Employee's Mobile Number");
				phoneno = sc.next();
				System.out.println("Enter Employee's Address");
				address = sc.next();
				
				Query q4=ss.createQuery("update mypojo set name=:n, phoneno=:p, address=:a where empno=:e"); 
				q4.setParameter("n",name);  
				q4.setParameter("p",phoneno);
				q4.setParameter("a",address);
				q4.setParameter("e", empno);
		 
				int status1=q4.executeUpdate();  
				System.out.println(empno +"row updated "+status1); 
				tx2.commit();
				break;
				
			case 4:
				
				break;
			case 5:
				System.exit(x);
				break;
			}
		
		
		
		
		
		
	}

	}
}
