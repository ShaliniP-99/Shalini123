package com.dineshonjava.bean;

public class CustomerBean {
	private Integer id;
	private String name;
	private String address;
	private Long phoneno;
	private String email;
	private String compname;
	private Integer age;
	private Long openbalance;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Long getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(Long phoneno) {
		this.phoneno = phoneno;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCompname() {
		return compname;
	}
	public void setCompname(String compname) {
		this.compname = compname;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public Long getOpenbalance() {
		return openbalance;
	}
	public void setOpenbalance(Long openbalance) {
		this.openbalance = openbalance;
	}
	
	
}
